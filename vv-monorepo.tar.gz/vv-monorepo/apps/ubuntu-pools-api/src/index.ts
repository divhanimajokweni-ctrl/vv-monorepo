import { buildServer } from './server'
import { config } from './config'

async function main() {
  const app = await buildServer()
  await app.listen({ port: config.PORT, host: '0.0.0.0' })
  app.log.info(`Ubuntu Pools API running on port ${config.PORT}`)
  app.log.info(`Health check: http://localhost:${config.PORT}/api/health`)
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
