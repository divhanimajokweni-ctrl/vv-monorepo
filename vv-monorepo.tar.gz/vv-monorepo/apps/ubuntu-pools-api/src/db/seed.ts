import 'dotenv/config'
import { db } from './client'
import { users, pools, poolMembers } from './schema'
import { v4 as uuidv4 } from 'uuid'

async function seed() {
  console.log('🌱 Seeding Ubuntu Pools pilot data...')

  // Seed admin user (Mino)
  const adminId = uuidv4()
  await db.insert(users).values({
    id: adminId,
    phone: '+27600000001',
    firstName: 'Mino',
    lastName: 'Director',
    status: 'active',
    ubuntuScore: '750',
    popiaConsentAt: new Date(),
  }).onConflictDoNothing()

  // Seed 5 waitlist pilot members
  const pilotMembers = []
  for (let i = 1; i <= 5; i++) {
    const id = uuidv4()
    pilotMembers.push(id)
    await db.insert(users).values({
      id,
      phone: `+2760000000${i + 1}`,
      firstName: `PilotMember${i}`,
      lastName: 'Waitlist',
      status: 'active',
      popiaConsentAt: new Date(),
    }).onConflictDoNothing()
  }

  // Seed pilot pool
  const poolId = uuidv4()
  await db.insert(pools).values({
    id: poolId,
    name: 'Ubuntu Pools Pilot Circle',
    adminId,
    targetAmount: '6000',
    currency: 'ZAR',
    cycleType: 'monthly',
    maxMembers: 12,
    tier: 'community',
    status: 'forming',
    safekrypteKeyId: `dev-key-pilot-${poolId}`,
  }).onConflictDoNothing()

  // Add admin + pilot members to pool
  await db.insert(poolMembers).values({ poolId, userId: adminId, payoutOrder: 1 }).onConflictDoNothing()
  for (let i = 0; i < pilotMembers.length; i++) {
    await db.insert(poolMembers).values({ poolId, userId: pilotMembers[i], payoutOrder: i + 2 }).onConflictDoNothing()
  }

  console.log('✅ Seed complete. Pilot pool:', poolId)
  process.exit(0)
}

seed().catch((err) => { console.error(err); process.exit(1) })
