import { pgTable, uuid, text, numeric, integer, timestamp, boolean, jsonb, pgEnum } from 'drizzle-orm/pg-core'

export const userStatusEnum = pgEnum('user_status', ['active','suspended','pending_verification','offboarded'])
export const poolStatusEnum = pgEnum('pool_status', ['forming','active','completed','suspended','disputed'])
export const poolTierEnum = pgEnum('pool_tier', ['community','professional','enterprise'])
export const contributionStatusEnum = pgEnum('contribution_status', ['pending','confirmed','failed','reversed'])

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  phone: text('phone').notNull().unique(),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  idNumberHash: text('id_number_hash'),             // SHA256 of SAID — never store plaintext
  status: userStatusEnum('status').notNull().default('pending_verification'),
  ubuntuScore: numeric('ubuntu_score', { precision: 7, scale: 2 }).default('500'),
  popiaConsentAt: timestamp('popia_consent_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const pools = pgTable('pools', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  status: poolStatusEnum('status').notNull().default('forming'),
  tier: poolTierEnum('tier').notNull().default('community'),
  adminId: uuid('admin_id').notNull().references(() => users.id),
  targetAmount: numeric('target_amount', { precision: 14, scale: 2 }).notNull(),
  currentBalance: numeric('current_balance', { precision: 14, scale: 2 }).notNull().default('0'),
  currency: text('currency').notNull().default('ZAR'),
  cycleType: text('cycle_type').notNull().default('monthly'),
  maxMembers: integer('max_members').notNull().default(12),
  safekrypteKeyId: text('safekrypte_key_id').notNull(),
  safestakesPoolId: text('safestakes_pool_id'),
  metadata: jsonb('metadata').default({}),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const poolMembers = pgTable('pool_members', {
  id: uuid('id').primaryKey().defaultRandom(),
  poolId: uuid('pool_id').notNull().references(() => pools.id),
  userId: uuid('user_id').notNull().references(() => users.id),
  joinedAt: timestamp('joined_at', { withTimezone: true }).notNull().defaultNow(),
  isActive: boolean('is_active').notNull().default(true),
  payoutOrder: integer('payout_order'),
})

export const contributions = pgTable('contributions', {
  id: uuid('id').primaryKey().defaultRandom(),
  poolId: uuid('pool_id').notNull().references(() => pools.id),
  userId: uuid('user_id').notNull().references(() => users.id),
  amount: numeric('amount', { precision: 14, scale: 2 }).notNull(),
  currency: text('currency').notNull().default('ZAR'),
  status: contributionStatusEnum('status').notNull().default('pending'),
  transactionRef: text('transaction_ref').notNull().unique(),
  safekrypteSignature: text('safekrypte_signature'),
  idempotencyKey: text('idempotency_key').notNull().unique(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  confirmedAt: timestamp('confirmed_at', { withTimezone: true }),
})

export const auditLog = pgTable('audit_log', {
  id: uuid('id').primaryKey().defaultRandom(),
  entityType: text('entity_type').notNull(),
  entityId: uuid('entity_id').notNull(),
  action: text('action').notNull(),
  actorId: uuid('actor_id'),
  payload: jsonb('payload'),
  traceId: uuid('trace_id').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})
