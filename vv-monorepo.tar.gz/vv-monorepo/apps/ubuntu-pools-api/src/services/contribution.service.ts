import { db } from '../db/client'
import { contributions, pools } from '../db/schema'
import { eq, sql } from 'drizzle-orm'
import { SafeKrypteService } from './safekrypte.service'

interface RecordContributionInput {
  poolId: string
  userId: string
  amount: number
  currency: string
  transactionRef: string
  idempotencyKey: string
  traceId: string
}

export class ContributionService {
  private safekrypte = new SafeKrypteService()

  async recordContribution(input: RecordContributionInput) {
    // Idempotency: if key exists, return existing record
    const [existing] = await db.select().from(contributions)
      .where(eq(contributions.idempotencyKey, input.idempotencyKey)).limit(1)
    if (existing) return existing

    // Get pool to sign against correct key
    const [pool] = await db.select().from(pools).where(eq(pools.id, input.poolId)).limit(1)
    if (!pool) throw new Error('Pool not found')

    // Sign the contribution via SafeKrypte
    const signature = await this.safekrypte.signContribution({
      poolKeyId: pool.safekrypteKeyId,
      payload: { poolId: input.poolId, userId: input.userId, amount: input.amount, ref: input.transactionRef },
      traceId: input.traceId,
    })

    const [contribution] = await db.insert(contributions).values({
      poolId: input.poolId,
      userId: input.userId,
      amount: String(input.amount),
      currency: input.currency,
      transactionRef: input.transactionRef,
      idempotencyKey: input.idempotencyKey,
      safekrypteSignature: signature,
      status: 'confirmed',
      confirmedAt: new Date(),
    }).returning()

    // Update pool balance atomically
    await db.update(pools)
      .set({ currentBalance: sql`current_balance + ${input.amount}`, updatedAt: new Date() })
      .where(eq(pools.id, input.poolId))

    return contribution
  }

  async listContributions(poolId: string) {
    return db.select().from(contributions).where(eq(contributions.poolId, poolId))
  }
}
