import { db } from '../db/client'
import { users, contributions, poolMembers } from '../db/schema'
import { eq } from 'drizzle-orm'
import { config } from '../config'

interface UbuntuScore {
  userId: string
  score: number
  components: {
    consistencyScore: number
    groupTrustScore: number
    repaymentScore: number
    participationScore: number
  }
  calculatedAt: string
}

export class UbuntuScoreService {
  async getScore(userId: string): Promise<UbuntuScore> {
    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1)
    if (!user) throw new Error('User not found')
    return {
      userId,
      score: Number(user.ubuntuScore ?? 500),
      components: { consistencyScore: 80, groupTrustScore: 75, repaymentScore: 90, participationScore: 70 },
      calculatedAt: new Date().toISOString(),
    }
  }

  async recalculateScore(userId: string, traceId: string): Promise<UbuntuScore> {
    // Pull contribution history for this user
    const userContributions = await db.select().from(contributions).where(eq(contributions.userId, userId))
    const memberships = await db.select().from(poolMembers).where(eq(poolMembers.userId, userId))

    // Score formula (simplified — LINDIWE runs the full ML model)
    const consistencyScore = userContributions.filter(c => c.status === 'confirmed').length * 10
    const participationScore = memberships.length * 15
    const rawScore = Math.min(1000, 400 + consistencyScore + participationScore)

    await db.update(users)
      .set({ ubuntuScore: String(rawScore), updatedAt: new Date() })
      .where(eq(users.id, userId))

    return {
      userId,
      score: rawScore,
      components: { consistencyScore, groupTrustScore: 75, repaymentScore: 90, participationScore },
      calculatedAt: new Date().toISOString(),
    }
  }
}
