import { db } from '../db/client'
import { poolMembers, pools, users } from '../db/schema'
import { eq, and } from 'drizzle-orm'

export class MemberService {
  async joinPool(poolId: string, userId: string, traceId: string) {
    const [pool] = await db.select().from(pools).where(eq(pools.id, poolId)).limit(1)
    if (!pool) throw new Error('Pool not found')
    if (pool.status !== 'forming' && pool.status !== 'active') {
      throw new Error('Pool is not accepting new members')
    }
    const [existing] = await db.select().from(poolMembers)
      .where(and(eq(poolMembers.poolId, poolId), eq(poolMembers.userId, userId))).limit(1)
    if (existing) throw new Error('Already a member of this pool')

    const [membership] = await db.insert(poolMembers).values({
      poolId,
      userId,
    }).returning()
    return membership
  }

  async listMembers(poolId: string) {
    return db.select({ member: users, membership: poolMembers })
      .from(poolMembers)
      .innerJoin(users, eq(poolMembers.userId, users.id))
      .where(and(eq(poolMembers.poolId, poolId), eq(poolMembers.isActive, true)))
  }
}
