import { config } from '../config'

export class SafeStakesService {
  private baseUrl = config.SAFESTAKES_BASE_URL

  async createStakePool(input: { poolId: string; adminId: string; traceId: string }) {
    if (config.NODE_ENV === 'development') {
      return { stakePoolId: `dev-stake-pool-${input.poolId}` }
    }
    const res = await fetch(`${this.baseUrl}/api/pools`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Trace-Id': input.traceId },
      body: JSON.stringify(input),
    })
    if (!res.ok) throw new Error(`SafeStakes pool creation failed: ${res.status}`)
    return res.json()
  }
}
