import { config } from '../config'

interface GenerateKeyResult { keyId: string; namespace: string }
interface SignResult { signature: string; keyId: string; timestamp: string }

export class SafeKrypteService {
  private baseUrl = config.SAFEKRYPTE_BASE_URL

  async generatePoolKey(traceId: string): Promise<GenerateKeyResult> {
    if (config.NODE_ENV === 'development') {
      // Software HSM simulation for dev
      return { keyId: `dev-key-${Date.now()}`, namespace: 'vv-dev' }
    }
    const res = await fetch(`${this.baseUrl}/api/hsm/keys/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Trace-Id': traceId },
      body: JSON.stringify({ type: 'pool', algorithm: 'ed25519' }),
    })
    if (!res.ok) throw new Error(`SafeKrypte key generation failed: ${res.status}`)
    return res.json()
  }

  async signContribution(input: { poolKeyId: string; payload: Record<string, unknown>; traceId: string }): Promise<string> {
    if (config.NODE_ENV === 'development') {
      // Dev simulation: return deterministic mock signature
      return `dev-sig-${Buffer.from(JSON.stringify(input.payload)).toString('base64').substring(0, 32)}`
    }
    const res = await fetch(`${this.baseUrl}/api/hsm/sign`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Trace-Id': input.traceId },
      body: JSON.stringify({ keyId: input.poolKeyId, payload: input.payload }),
    })
    if (!res.ok) throw new Error(`SafeKrypte signing failed: ${res.status}`)
    const data: SignResult = await res.json()
    return data.signature
  }
}
