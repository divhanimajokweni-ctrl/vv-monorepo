import { db } from '../db/client'
import { pools, poolMembers } from '../db/schema'
import { eq, and } from 'drizzle-orm'
import { SafeKrypteService } from './safekrypte.service'
import { generateTraceId } from '@vv/shared-kernel'

interface CreatePoolInput {
  name: string
  adminId: string
  targetAmount: number
  currency: string
  cycleType: string
  maxMembers: number
  tier: 'community' | 'professional' | 'enterprise'
  traceId: string
}

export class PoolService {
  private safekrypte = new SafeKrypteService()

  async createPool(input: CreatePoolInput) {
    // 1. Request a key from SafeKrypte for this pool
    const key = await this.safekrypte.generatePoolKey(input.traceId)

    // 2. Create pool record
    const [pool] = await db.insert(pools).values({
      name: input.name,
      adminId: input.adminId,
      targetAmount: String(input.targetAmount),
      currency: input.currency,
      cycleType: input.cycleType,
      maxMembers: input.maxMembers,
      tier: input.tier,
      safekrypteKeyId: key.keyId,
    }).returning()

    // 3. Admin becomes first member
    await db.insert(poolMembers).values({
      poolId: pool.id,
      userId: input.adminId,
      payoutOrder: 1,
    })

    return pool
  }

  async getPool(poolId: string, requestingUserId: string) {
    const [pool] = await db.select().from(pools).where(eq(pools.id, poolId)).limit(1)
    return pool ?? null
  }

  async listUserPools(userId: string) {
    const memberships = await db
      .select({ pool: pools })
      .from(poolMembers)
      .innerJoin(pools, eq(poolMembers.poolId, pools.id))
      .where(and(eq(poolMembers.userId, userId), eq(poolMembers.isActive, true)))
    return memberships.map(m => m.pool)
  }
}
