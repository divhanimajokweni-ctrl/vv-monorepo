import Fastify from 'fastify'
import fastifyJwt from '@fastify/jwt'
import fastifyCors from '@fastify/cors'
import fastifyRateLimit from '@fastify/rate-limit'
import { config } from './config'
import { healthRoutes, poolRoutes, memberRoutes, contributionRoutes, creditRoutes, authRoutes } from './routes'

declare module 'fastify' {
  interface FastifyInstance {
    authenticate: (req: FastifyRequest, reply: FastifyReply) => Promise<void>
  }
}

export async function buildServer() {
  const app = Fastify({
    logger: { level: config.LOG_LEVEL },
    disableRequestLogging: false,
    trustProxy: true,
  })

  // Plugins
  await app.register(fastifyCors, { origin: true })
  await app.register(fastifyRateLimit, { max: 100, timeWindow: '1 minute' })
  await app.register(fastifyJwt, { secret: config.JWT_SECRET })

  // Auth decorator
  app.decorate('authenticate', async function (request, reply) {
    try {
      await request.jwtVerify()
    } catch (err) {
      reply.code(401).send({ error: 'Unauthorized' })
    }
  })

  // Routes
  await app.register(authRoutes)
  await app.register(healthRoutes)
  await app.register(poolRoutes)
  await app.register(memberRoutes)
  await app.register(contributionRoutes)
  await app.register(creditRoutes)

  // Global error handler
  app.setErrorHandler((error, _req, reply) => {
    app.log.error(error)
    if (error.validation) {
      return reply.code(400).send({ error: 'Validation error', details: error.validation })
    }
    reply.code(error.statusCode ?? 500).send({ error: error.message ?? 'Internal server error' })
  })

  return app
}
