import { FastifyInstance } from 'fastify'
import { MemberService } from '../services/member.service'
import { generateTraceId } from '@vv/shared-kernel'

export async function memberRoutes(app: FastifyInstance) {
  const memberService = new MemberService()

  app.post('/api/pools/:poolId/members', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { poolId } = req.params as { poolId: string }
    const result = await memberService.joinPool(poolId, req.user.id, traceId)
    return reply.code(201).send({ data: result, traceId })
  })

  app.get('/api/pools/:poolId/members', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { poolId } = req.params as { poolId: string }
    const members = await memberService.listMembers(poolId)
    return reply.code(200).send({ data: members, traceId })
  })
}
