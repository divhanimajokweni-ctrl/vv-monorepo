import { FastifyInstance } from 'fastify'
import { db } from '../db/client'
import { sql } from 'drizzle-orm'

export async function healthRoutes(app: FastifyInstance) {
  // Primary health check — this is the GATE-2 north star endpoint
  app.get('/api/health', async (_req, reply) => {
    try {
      await db.execute(sql`SELECT 1`)
      return reply.code(200).send({
        status: 'ok',
        service: 'ubuntu-pools-api',
        timestamp: new Date().toISOString(),
        gate: 'GATE-2-READY',
        db: 'connected',
        version: process.env.npm_package_version ?? '1.0.0',
      })
    } catch (err) {
      return reply.code(503).send({
        status: 'error',
        service: 'ubuntu-pools-api',
        timestamp: new Date().toISOString(),
        db: 'disconnected',
        error: err instanceof Error ? err.message : 'unknown',
      })
    }
  })

  app.get('/api/health/deep', { onRequest: [app.authenticate] }, async (_req, reply) => {
    const checks = {
      db: false,
      redis: false,
      safekrypte: false,
    }
    try { await db.execute(sql`SELECT 1`); checks.db = true } catch {}
    return reply.code(checks.db ? 200 : 503).send({
      status: Object.values(checks).every(Boolean) ? 'ok' : 'degraded',
      checks,
      timestamp: new Date().toISOString(),
    })
  })
}
