import { FastifyInstance } from 'fastify'
import { z } from 'zod'
import { ContributionService } from '../services/contribution.service'
import { generateTraceId, generateIdempotencyKey } from '@vv/shared-kernel'

const CreateContributionSchema = z.object({
  amount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']).default('ZAR'),
  transactionRef: z.string(),
})

export async function contributionRoutes(app: FastifyInstance) {
  const contributionService = new ContributionService()

  app.post('/api/pools/:poolId/contributions', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { poolId } = req.params as { poolId: string }
    const body = CreateContributionSchema.parse(req.body)
    const idempotencyKey = generateIdempotencyKey(`${req.user.id}:${poolId}:${body.transactionRef}`)
    const contribution = await contributionService.recordContribution({
      ...body,
      poolId,
      userId: req.user.id,
      idempotencyKey,
      traceId,
    })
    return reply.code(201).send({ data: contribution, traceId })
  })

  app.get('/api/pools/:poolId/contributions', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { poolId } = req.params as { poolId: string }
    const contributions = await contributionService.listContributions(poolId)
    return reply.code(200).send({ data: contributions, traceId })
  })
}
