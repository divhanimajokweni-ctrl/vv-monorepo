import { FastifyInstance } from 'fastify'
import { z } from 'zod'
import { db } from '../db/client'
import { users } from '../db/schema'
import { eq } from 'drizzle-orm'
import { generateTraceId, validateSAPhone } from '@vv/shared-kernel'

const LoginSchema = z.object({
  phone: z.string().refine(validateSAPhone, 'Invalid SA phone number'),
  otp: z.string().length(6),
})

export async function authRoutes(app: FastifyInstance) {
  // Request OTP
  app.post('/api/auth/otp/request', async (req, reply) => {
    const traceId = generateTraceId()
    const { phone } = z.object({ phone: z.string() }).parse(req.body)
    if (!validateSAPhone(phone)) {
      return reply.code(400).send({ error: 'Invalid South African phone number', traceId })
    }
    // In production: integrate Twilio or Africa's Talking OTP
    // For dev: OTP is always 123456
    app.log.info({ phone, traceId }, 'OTP requested')
    return reply.code(200).send({ message: 'OTP sent', traceId })
  })

  // Verify OTP → issue JWT
  app.post('/api/auth/otp/verify', async (req, reply) => {
    const traceId = generateTraceId()
    const { phone, otp } = LoginSchema.parse(req.body)
    if (process.env.NODE_ENV !== 'production' && otp !== '123456') {
      return reply.code(401).send({ error: 'Invalid OTP', traceId })
    }
    let [user] = await db.select().from(users).where(eq(users.phone, phone)).limit(1)
    if (!user) {
      const [created] = await db.insert(users).values({
        phone,
        firstName: 'Member',
        lastName: '',
        status: 'pending_verification',
      }).returning()
      user = created
    }
    const token = app.jwt.sign({ id: user.id, phone: user.phone, role: 'member' })
    return reply.code(200).send({ token, userId: user.id, traceId })
  })
}
