import { FastifyInstance } from 'fastify'
import { z } from 'zod'
import { PoolService } from '../services/pool.service'
import { generateTraceId } from '@vv/shared-kernel'

const CreatePoolSchema = z.object({
  name: z.string().min(3).max(80),
  targetAmount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']).default('ZAR'),
  cycleType: z.enum(['monthly', 'weekly', 'biweekly']).default('monthly'),
  maxMembers: z.number().int().min(2).max(50).default(12),
  tier: z.enum(['community', 'professional', 'enterprise']).default('community'),
})

export async function poolRoutes(app: FastifyInstance) {
  const poolService = new PoolService()

  app.post('/api/pools', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const body = CreatePoolSchema.parse(req.body)
    const pool = await poolService.createPool({ ...body, adminId: req.user.id, traceId })
    return reply.code(201).send({ data: pool, traceId })
  })

  app.get('/api/pools', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const pools = await poolService.listUserPools(req.user.id)
    return reply.code(200).send({ data: pools, traceId })
  })

  app.get('/api/pools/:poolId', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { poolId } = req.params as { poolId: string }
    const pool = await poolService.getPool(poolId, req.user.id)
    if (!pool) return reply.code(404).send({ error: 'Pool not found', traceId })
    return reply.code(200).send({ data: pool, traceId })
  })
}
