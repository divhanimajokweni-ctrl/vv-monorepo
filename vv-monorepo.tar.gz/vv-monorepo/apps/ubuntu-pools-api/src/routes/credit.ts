import { FastifyInstance } from 'fastify'
import { UbuntuScoreService } from '../services/ubuntu-score.service'
import { generateTraceId } from '@vv/shared-kernel'

export async function creditRoutes(app: FastifyInstance) {
  const scoreService = new UbuntuScoreService()

  app.get('/api/members/:userId/score', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { userId } = req.params as { userId: string }
    const score = await scoreService.getScore(userId)
    return reply.code(200).send({ data: score, traceId })
  })

  app.post('/api/members/:userId/score/refresh', { onRequest: [app.authenticate] }, async (req, reply) => {
    const traceId = generateTraceId()
    const { userId } = req.params as { userId: string }
    const score = await scoreService.recalculateScore(userId, traceId)
    return reply.code(200).send({ data: score, traceId })
  })
}
