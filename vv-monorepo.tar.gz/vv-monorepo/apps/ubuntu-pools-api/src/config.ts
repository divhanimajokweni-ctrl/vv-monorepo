import { z } from 'zod'
import 'dotenv/config'

const ConfigSchema = z.object({
  NODE_ENV: z.enum(['development', 'staging', 'production']).default('development'),
  PORT: z.coerce.number().default(3001),
  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().default('redis://localhost:6379'),
  JWT_SECRET: z.string().min(32),
  JWT_EXPIRY: z.string().default('7d'),
  ANTHROPIC_API_KEY: z.string().optional(),
  SAFEKRYPTE_BASE_URL: z.string().default('http://localhost:3004'),
  SAFESTAKES_BASE_URL: z.string().default('http://localhost:3003'),
  TWILIO_ACCOUNT_SID: z.string().optional(),
  TWILIO_AUTH_TOKEN: z.string().optional(),
  LOG_LEVEL: z.enum(['trace','debug','info','warn','error']).default('info'),
})

export const config = ConfigSchema.parse(process.env)
export type Config = z.infer<typeof ConfigSchema>
