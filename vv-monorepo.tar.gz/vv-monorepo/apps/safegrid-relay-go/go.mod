module github.com/vv-llc/safegrid-relay

go 1.23

require (
  github.com/go-redis/redis/v9 v9.7.0
  go.uber.org/zap v1.27.0
  github.com/spf13/viper v1.19.0
)
