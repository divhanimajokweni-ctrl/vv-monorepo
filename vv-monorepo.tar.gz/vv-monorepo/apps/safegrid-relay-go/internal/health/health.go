package health

import (
  "encoding/json"
  "fmt"
  "net/http"
  "time"

  "go.uber.org/zap"
)

type HealthResponse struct {
  Status    string `json:"status"`
  Service   string `json:"service"`
  Timestamp string `json:"timestamp"`
}

func ServeHTTP(port int, logger *zap.Logger) {
  mux := http.NewServeMux()
  mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusOK)
    json.NewEncoder(w).Encode(HealthResponse{
      Status:    "ok",
      Service:   "safegrid-relay",
      Timestamp: time.Now().UTC().Format(time.RFC3339),
    })
  })

  addr := fmt.Sprintf(":%d", port)
  logger.Info("Health endpoint listening", zap.String("addr", addr))
  if err := http.ListenAndServe(addr, mux); err != nil {
    logger.Error("Health server error", zap.Error(err))
  }
}
