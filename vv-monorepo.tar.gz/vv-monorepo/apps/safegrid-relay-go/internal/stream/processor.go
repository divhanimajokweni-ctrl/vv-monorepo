package stream

import (
  "bytes"
  "context"
  "encoding/json"
  "fmt"
  "net/http"
  "time"

  "github.com/go-redis/redis/v9"
  "github.com/vv-llc/safegrid-relay/internal/config"
  "go.uber.org/zap"
)

type Processor struct {
  cfg    *config.Config
  redis  *redis.Client
  logger *zap.Logger
  client *http.Client
}

type FrameEvent struct {
  CameraID    string `json:"cameraId"`
  SiteID      string `json:"siteId"`
  Description string `json:"description"`
  Timestamp   string `json:"timestamp"`
  TraceID     string `json:"traceId"`
}

func NewProcessor(cfg *config.Config, logger *zap.Logger) (*Processor, error) {
  opt, err := redis.ParseURL(cfg.RedisURL)
  if err != nil {
    return nil, fmt.Errorf("invalid redis URL: %w", err)
  }
  return &Processor{
    cfg:    cfg,
    redis:  redis.NewClient(opt),
    logger: logger,
    client: &http.Client{Timeout: 10 * time.Second},
  }, nil
}

func (p *Processor) Run(ctx context.Context) error {
  channel := fmt.Sprintf("safegrid:frames:%s", p.cfg.NodeID)
  sub := p.redis.Subscribe(ctx, channel)
  defer sub.Close()

  p.logger.Info("Listening for frames", zap.String("channel", channel))

  for {
    select {
    case <-ctx.Done():
      return nil
    case msg := <-sub.Channel():
      var frame FrameEvent
      if err := json.Unmarshal([]byte(msg.Payload), &frame); err != nil {
        p.logger.Warn("Failed to parse frame event", zap.Error(err))
        continue
      }
      go p.processFrame(ctx, frame)
    }
  }
}

func (p *Processor) processFrame(ctx context.Context, frame FrameEvent) {
  body, _ := json.Marshal(map[string]interface{}{
    "siteId":           frame.SiteID,
    "cameraId":         frame.CameraID,
    "imageDescription": frame.Description,
    "traceId":          frame.TraceID,
  })

  req, err := http.NewRequestWithContext(ctx, "POST", p.cfg.SafeGridAPIURL+"/api/alerts/ingest", bytes.NewBuffer(body))
  if err != nil {
    p.logger.Error("Failed to create alert request", zap.Error(err))
    return
  }
  req.Header.Set("Content-Type", "application/json")

  resp, err := p.client.Do(req)
  if err != nil {
    p.logger.Error("Alert ingest failed", zap.Error(err))
    return
  }
  defer resp.Body.Close()

  p.logger.Info("Alert ingested",
    zap.String("cameraId", frame.CameraID),
    zap.Int("status", resp.StatusCode),
  )
}
