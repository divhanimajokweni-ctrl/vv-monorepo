package config

import (
  "github.com/spf13/viper"
)

type Config struct {
  NodeID          string `mapstructure:"NODE_ID"`
  Region          string `mapstructure:"REGION"`
  RedisURL        string `mapstructure:"REDIS_URL"`
  SafeGridAPIURL  string `mapstructure:"SAFEGRID_API_URL"`
  InferenceURL    string `mapstructure:"INFERENCE_BASE_URL"`
  HealthPort      int    `mapstructure:"HEALTH_PORT"`
  StreamBufferSize int   `mapstructure:"STREAM_BUFFER_SIZE"`
}

func Load() (*Config, error) {
  viper.AutomaticEnv()
  viper.SetDefault("HEALTH_PORT", 8080)
  viper.SetDefault("REGION", "ZA-EC")
  viper.SetDefault("STREAM_BUFFER_SIZE", 100)
  viper.SetDefault("REDIS_URL", "redis://localhost:6379")
  viper.SetDefault("SAFEGRID_API_URL", "http://localhost:3002")
  viper.SetDefault("INFERENCE_BASE_URL", "http://localhost:11434")

  var cfg Config
  if err := viper.Unmarshal(&cfg); err != nil {
    return nil, err
  }
  if cfg.NodeID == "" {
    cfg.NodeID = "relay-node-" + cfg.Region + "-01"
  }
  return &cfg, nil
}
