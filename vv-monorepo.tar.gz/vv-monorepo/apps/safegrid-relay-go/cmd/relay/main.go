package main

import (
  "context"
  "fmt"
  "os"
  "os/signal"
  "syscall"

  "github.com/vv-llc/safegrid-relay/internal/config"
  "github.com/vv-llc/safegrid-relay/internal/health"
  "github.com/vv-llc/safegrid-relay/internal/stream"
  "go.uber.org/zap"
)

func main() {
  logger, _ := zap.NewProduction()
  defer logger.Sync()

  cfg, err := config.Load()
  if err != nil {
    logger.Fatal("Failed to load config", zap.Error(err))
  }

  ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
  defer cancel()

  // Start health endpoint
  go health.ServeHTTP(cfg.HealthPort, logger)

  // Start stream processor
  processor, err := stream.NewProcessor(cfg, logger)
  if err != nil {
    logger.Fatal("Failed to create processor", zap.Error(err))
  }

  logger.Info("SafeGrid relay node started",
    zap.String("nodeId", cfg.NodeID),
    zap.String("region", cfg.Region),
    zap.Int("healthPort", cfg.HealthPort),
  )

  if err := processor.Run(ctx); err != nil {
    fmt.Fprintf(os.Stderr, "Processor error: %v\n", err)
    os.Exit(1)
  }

  logger.Info("SafeGrid relay node stopped cleanly")
}
