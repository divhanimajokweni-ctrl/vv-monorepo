import { config } from '../config'

export type HSMMode = 'software' | 'aws-cloudhsm' | 'azure-dedicated'

export interface HSMKey {
  keyId: string
  algorithm: string
  namespace: string
  createdAt: string
  ceremonyRef?: string
}

export interface HSMSignResult {
  signature: string
  keyId: string
  algorithm: string
  timestamp: string
  attestation: string
}

export class HSMClient {
  private mode: HSMMode

  constructor(mode: HSMMode = 'software') {
    this.mode = mode
  }

  async generateKey(opts: { type: string; algorithm: string; namespace: string }): Promise<HSMKey> {
    if (this.mode === 'software') return this.softwareGenerateKey(opts)
    // Production: delegate to AWS CloudHSM or Azure Dedicated HSM SDK
    throw new Error(`HSM mode ${this.mode} not yet wired in this environment`)
  }

  async sign(keyId: string, payload: string): Promise<HSMSignResult> {
    if (this.mode === 'software') return this.softwareSign(keyId, payload)
    throw new Error(`HSM mode ${this.mode} not yet wired in this environment`)
  }

  // ── Software HSM simulation (development only) ──
  private async softwareGenerateKey(opts: { type: string; algorithm: string; namespace: string }): Promise<HSMKey> {
    const crypto = await import('crypto')
    const keyId = `sw-${opts.namespace}-${opts.type}-${crypto.randomBytes(8).toString('hex')}`
    return {
      keyId,
      algorithm: opts.algorithm,
      namespace: opts.namespace,
      createdAt: new Date().toISOString(),
      ceremonyRef: 'software-simulated',
    }
  }

  private async softwareSign(keyId: string, payload: string): Promise<HSMSignResult> {
    const crypto = await import('crypto')
    const signature = crypto.createHmac('sha256', `sw-secret-${keyId}`).update(payload).digest('hex')
    return {
      signature,
      keyId,
      algorithm: 'hmac-sha256-sw',
      timestamp: new Date().toISOString(),
      attestation: `sw-attestation-${signature.substring(0, 16)}`,
    }
  }
}
