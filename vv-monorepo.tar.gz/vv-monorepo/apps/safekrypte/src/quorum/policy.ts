// Quorum policy definitions
// These are the m-of-n thresholds that govern SafeKrypte operations
// Guardianship Council threshold: 3-of-5 required for escrow policy

export interface QuorumPolicy {
  operation: string
  required: number
  total: number
  description: string
  roles: string[]
}

export const QUORUM_POLICIES: Record<string, QuorumPolicy> = {
  generate_root_key: {
    operation: 'generate_root_key',
    required: 5,
    total: 7,
    description: 'Root key generation requires 5 of 7 authorized signers',
    roles: ['director', 'guardian_g1', 'guardian_g2', 'guardian_g3', 'auditor', 'operator_1', 'operator_2'],
  },
  sign_transaction: {
    operation: 'sign_transaction',
    required: 2,
    total: 3,
    description: 'Standard transaction signing requires 2 of 3 operators',
    roles: ['operator_1', 'operator_2', 'operator_3'],
  },
  rotate_key: {
    operation: 'rotate_key',
    required: 4,
    total: 7,
    description: 'Key rotation requires 4 of 7 authorized signers',
    roles: ['director', 'guardian_g1', 'guardian_g2', 'guardian_g3', 'auditor', 'operator_1', 'operator_2'],
  },
  escrow_policy: {
    operation: 'escrow_policy',
    required: 3,
    total: 5,
    description: 'Guardianship Council: 3 of 5 for escrow policy changes (SafeKrypte constitutional)',
    roles: ['guardian_g1', 'guardian_g2', 'guardian_g3', 'guardian_g4', 'guardian_g5'],
  },
  disaster_recovery: {
    operation: 'disaster_recovery',
    required: 5,
    total: 7,
    description: 'Break-glass recovery requires 5 of 7 with video record and legal witness',
    roles: ['director', 'guardian_g1', 'guardian_g2', 'guardian_g3', 'auditor', 'operator_1', 'legal_witness'],
  },
}

export function validateQuorum(operation: string, signerRoles: string[]): { valid: boolean; reason: string } {
  const policy = QUORUM_POLICIES[operation]
  if (!policy) return { valid: false, reason: `Unknown operation: ${operation}` }

  const validSigners = signerRoles.filter(r => policy.roles.includes(r))
  if (validSigners.length < policy.required) {
    return {
      valid: false,
      reason: `Quorum not met: ${validSigners.length}/${policy.required} required for ${operation}`,
    }
  }
  return { valid: true, reason: 'Quorum satisfied' }
}
