import { pgTable, uuid, text, numeric, integer, timestamp, boolean, jsonb, vector, pgEnum } from 'drizzle-orm/pg-core'

export const severityEnum = pgEnum('severity', ['low', 'medium', 'high', 'critical'])
export const alertStatusEnum = pgEnum('alert_status', ['new', 'acknowledged', 'resolved', 'false_positive'])

export const tenants = pgTable('tenants', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  apiKey: text('api_key').notNull().unique(),
  tier: text('tier').notNull().default('starter'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const sites = pgTable('sites', {
  id: uuid('id').primaryKey().defaultRandom(),
  tenantId: uuid('tenant_id').notNull().references(() => tenants.id),
  name: text('name').notNull(),
  address: text('address'),
  lat: numeric('lat', { precision: 10, scale: 7 }),
  lng: numeric('lng', { precision: 10, scale: 7 }),
  suburb: text('suburb'),
  province: text('province').default('Eastern Cape'),
  cameraCount: integer('camera_count').default(0),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const alerts = pgTable('alerts', {
  id: uuid('id').primaryKey().defaultRandom(),
  siteId: uuid('site_id').notNull().references(() => sites.id),
  cameraId: text('camera_id').notNull(),
  severity: severityEnum('severity').notNull(),
  threatType: text('threat_type').notNull(),
  confidence: numeric('confidence', { precision: 5, scale: 4 }),
  status: alertStatusEnum('status').notNull().default('new'),
  isDuplicate: boolean('is_duplicate').notNull().default(false),
  deduplicationHash: text('dedup_hash'),
  embedding: vector('embedding', { dimensions: 1536 }),
  rawPayload: jsonb('raw_payload'),
  timestamp: timestamp('timestamp', { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp('resolved_at', { withTimezone: true }),
})
