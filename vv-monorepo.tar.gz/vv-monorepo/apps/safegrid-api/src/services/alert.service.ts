import { db } from '../db/client'
import { alerts } from '../db/schema'
import { eq, desc } from 'drizzle-orm'
import { ThreatEngine } from '../brain/threat-engine'
import { DedupService } from './dedup.service'
import { generateEmbedding } from '../brain/embeddings'
import { generateTraceId } from '@vv/shared-kernel'

interface IngestAlertInput {
  siteId: string
  cameraId: string
  imageDescription: string
  contextHistory?: string[]
  traceId?: string
}

export class AlertService {
  private threatEngine = new ThreatEngine()
  private dedupService = new DedupService()

  async ingestAlert(input: IngestAlertInput) {
    const traceId = input.traceId ?? generateTraceId()

    // 1. Classify threat
    const classification = await this.threatEngine.classify({
      cameraId: input.cameraId,
      imageDescription: input.imageDescription,
      contextHistory: input.contextHistory ?? [],
    })

    // 2. Generate embedding
    const embedding = await generateEmbedding(`${classification.threatType}:${input.imageDescription}`)

    // 3. Check deduplication
    const dedup = await this.dedupService.checkDuplicate({
      siteId: input.siteId,
      threatType: classification.threatType,
      description: input.imageDescription,
    })

    // 4. Persist alert
    const [alert] = await db.insert(alerts).values({
      siteId: input.siteId,
      cameraId: input.cameraId,
      severity: classification.severity,
      threatType: classification.threatType,
      confidence: String(classification.confidence),
      status: dedup.isDuplicate ? 'acknowledged' : 'new',
      isDuplicate: dedup.isDuplicate,
      embedding,
    }).returning()

    return { alert, classification, isDuplicate: dedup.isDuplicate, traceId }
  }

  async listAlerts(siteId: string, limit = 50) {
    return db.select().from(alerts).where(eq(alerts.siteId, siteId))
      .orderBy(desc(alerts.timestamp)).limit(limit)
  }
}
