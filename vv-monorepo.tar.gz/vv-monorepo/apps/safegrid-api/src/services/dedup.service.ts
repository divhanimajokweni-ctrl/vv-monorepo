import { generateEmbedding, cosineSimilarity } from '../brain/embeddings'
import { db } from '../db/client'
import { alerts } from '../db/schema'
import { sql } from 'drizzle-orm'

const DEDUP_THRESHOLD = 0.92  // Alerts with cosine similarity above this are considered duplicates

export class DedupService {
  async checkDuplicate(input: {
    siteId: string
    threatType: string
    description: string
    windowMinutes?: number
  }): Promise<{ isDuplicate: boolean; similarAlertId?: string; similarity?: number }> {
    const embedding = await generateEmbedding(`${input.threatType}:${input.description}`)
    const windowMinutes = input.windowMinutes ?? 30

    // pgvector cosine distance query within recent window
    const recent = await db.execute(sql`
      SELECT id, embedding, 1 - (embedding <=> ${JSON.stringify(embedding)}::vector) as similarity
      FROM alerts
      WHERE site_id = ${input.siteId}::uuid
        AND timestamp > NOW() - INTERVAL '${windowMinutes} minutes'
        AND embedding IS NOT NULL
      ORDER BY similarity DESC
      LIMIT 1
    `)

    if (recent.length > 0) {
      const top = recent[0] as { id: string; similarity: number }
      if (top.similarity >= DEDUP_THRESHOLD) {
        return { isDuplicate: true, similarAlertId: top.id, similarity: top.similarity }
      }
    }

    return { isDuplicate: false }
  }
}
