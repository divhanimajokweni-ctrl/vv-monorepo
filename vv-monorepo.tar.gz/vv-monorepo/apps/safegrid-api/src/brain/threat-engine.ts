import { config as cfg } from '../config'

export interface ThreatClassification {
  threatType: string
  confidence: number
  severity: 'low' | 'medium' | 'high' | 'critical'
  reasoning: string
}

export class ThreatEngine {
  async classify(frameData: {
    cameraId: string
    imageDescription: string
    contextHistory: string[]
  }): Promise<ThreatClassification> {
    // In production: uses LINDIWE's local inference via InferenceRouter
    // In dev: returns a deterministic mock
    if (process.env.NODE_ENV === 'development') {
      return {
        threatType: 'perimeter_breach',
        confidence: 0.87,
        severity: 'medium',
        reasoning: 'Dev simulation: motion detected near perimeter fence',
      }
    }

    const res = await fetch(`${process.env.INFERENCE_BASE_URL}/classify/threat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(frameData),
    })
    return res.json()
  }
}
