import crypto from 'crypto'

// Generates embeddings for deduplication using cosine similarity
// In production: calls LINDIWE / Anthropic embeddings API
export async function generateEmbedding(text: string): Promise<number[]> {
  if (process.env.NODE_ENV === 'development') {
    // Deterministic mock embedding for dev
    const hash = crypto.createHash('sha256').update(text).digest()
    const embedding: number[] = []
    for (let i = 0; i < 1536; i++) {
      embedding.push((hash[i % 32] / 255) * 2 - 1)
    }
    return embedding
  }
  // Production: call inference router
  const res = await fetch(`${process.env.INFERENCE_BASE_URL}/embeddings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text }),
  })
  const data = await res.json()
  return data.embedding
}

export function cosineSimilarity(a: number[], b: number[]): number {
  const dot = a.reduce((sum, val, i) => sum + val * b[i], 0)
  const magA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0))
  const magB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0))
  return dot / (magA * magB)
}
