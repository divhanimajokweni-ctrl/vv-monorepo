import Fastify from 'fastify'
import fastifyJwt from '@fastify/jwt'
import fastifyCors from '@fastify/cors'
import 'dotenv/config'

const PORT = parseInt(process.env.PORT ?? '3000')
const JWT_SECRET = process.env.JWT_SECRET ?? 'dev-secret'

async function main() {
  const app = Fastify({ logger: { level: 'info' }, trustProxy: true })

  await app.register(fastifyCors, { origin: true })
  await app.register(fastifyJwt, { secret: JWT_SECRET })

  // Health
  app.get('/health', async () => ({ status: 'ok', service: 'enterprise-gateway', timestamp: new Date().toISOString() }))

  // Proxy routes (in production: use @fastify/http-proxy)
  app.all('/pools/*', async (req, reply) => {
    reply.code(502).send({ error: 'Proxy not configured — set POOLS_API_URL' })
  })

  await app.listen({ port: PORT, host: '0.0.0.0' })
  console.log(`Enterprise Gateway running on :${PORT}`)
}

main().catch(console.error)
