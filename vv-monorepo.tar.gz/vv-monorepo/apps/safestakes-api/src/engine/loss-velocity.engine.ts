import { VelocityLevel } from '@vv/shared-kernel'

export interface VelocityWindow {
  userId: string
  totalLoss: number
  currency: string
  windowHours: number
  transactionCount: number
  velocityScore: number
  level: VelocityLevel
  triggerRedirect: boolean
}

interface LossEvent {
  amount: number
  timestamp: string
  currency: string
}

const VELOCITY_THRESHOLDS = {
  safe: 0,
  watch: 25,
  warning: 55,
  critical: 80,   // Redirect triggers at critical
}

const REDIRECT_THRESHOLD = 79

export class LossVelocityEngine {
  calculateVelocity(events: LossEvent[], windowHours = 24): VelocityWindow & { userId: string } {
    const windowStart = Date.now() - windowHours * 60 * 60 * 1000
    const windowEvents = events.filter(e => new Date(e.timestamp).getTime() > windowStart)

    const totalLoss = windowEvents.reduce((sum, e) => sum + e.amount, 0)
    const transactionCount = windowEvents.length

    // Velocity score: combination of total loss, transaction frequency, and acceleration
    const lossScore = Math.min(50, totalLoss / 100)  // Every R100 = 1 point, max 50
    const frequencyScore = Math.min(30, transactionCount * 3)  // Every tx = 3 points, max 30
    const accelerationScore = this.calculateAcceleration(windowEvents)  // 0-20

    const velocityScore = Math.round(lossScore + frequencyScore + accelerationScore)

    let level: VelocityLevel = 'safe'
    if (velocityScore >= VELOCITY_THRESHOLDS.critical) level = 'critical'
    else if (velocityScore >= VELOCITY_THRESHOLDS.warning) level = 'warning'
    else if (velocityScore >= VELOCITY_THRESHOLDS.watch) level = 'watch'

    return {
      userId: '',   // Set by caller
      totalLoss,
      currency: windowEvents[0]?.currency ?? 'ZAR',
      windowHours,
      transactionCount,
      velocityScore,
      level,
      triggerRedirect: velocityScore >= REDIRECT_THRESHOLD,
    }
  }

  private calculateAcceleration(events: LossEvent[]): number {
    if (events.length < 3) return 0
    const sorted = [...events].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    const firstHalf = sorted.slice(0, Math.floor(sorted.length / 2))
    const secondHalf = sorted.slice(Math.floor(sorted.length / 2))
    const firstAvg = firstHalf.reduce((s, e) => s + e.amount, 0) / firstHalf.length
    const secondAvg = secondHalf.reduce((s, e) => s + e.amount, 0) / secondHalf.length
    return Math.min(20, Math.max(0, (secondAvg - firstAvg) / 10))
  }
}
