import { pgTable, uuid, text, numeric, integer, timestamp, boolean, jsonb, pgEnum } from 'drizzle-orm/pg-core'

export const stakeStatusEnum = pgEnum('stake_status', ['locked', 'released', 'slashed', 'pending'])
export const velocityLevelEnum = pgEnum('velocity_level', ['safe', 'watch', 'warning', 'critical'])

export const stakePools = pgTable('stake_pools', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  ownerEntityId: text('owner_entity_id').notNull(),
  ownerEntityType: text('owner_entity_type').notNull().default('ubuntu_pool'),
  safekrypteKeyId: text('safekrypte_key_id').notNull(),
  totalStaked: numeric('total_staked', { precision: 14, scale: 2 }).default('0'),
  currency: text('currency').default('ZAR'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const stakes = pgTable('stakes', {
  id: uuid('id').primaryKey().defaultRandom(),
  stakePoolId: uuid('stake_pool_id').notNull().references(() => stakePools.id),
  stakerId: text('staker_id').notNull(),
  amount: numeric('amount', { precision: 14, scale: 2 }).notNull(),
  currency: text('currency').notNull().default('ZAR'),
  status: stakeStatusEnum('status').notNull().default('pending'),
  receiptHash: text('receipt_hash').notNull(),
  idempotencyKey: text('idempotency_key').notNull().unique(),
  safekrypteSignature: text('safekrypte_signature'),
  metadata: jsonb('metadata').default({}),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  settledAt: timestamp('settled_at', { withTimezone: true }),
})

export const velocityEvents = pgTable('velocity_events', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  amount: numeric('amount', { precision: 14, scale: 2 }).notNull(),
  currency: text('currency').notNull().default('ZAR'),
  transactionRef: text('transaction_ref').notNull(),
  velocityScore: integer('velocity_score'),
  level: velocityLevelEnum('level'),
  redirectTriggered: boolean('redirect_triggered').default(false),
  redirectPoolId: uuid('redirect_pool_id'),
  traceId: uuid('trace_id').notNull(),
  timestamp: timestamp('timestamp', { withTimezone: true }).notNull().defaultNow(),
})
