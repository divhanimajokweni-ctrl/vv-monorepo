# VV — Venture Vision Monorepo

**Vaguely Vanity LLC (CIPC 2026/259053/07) | Pro Installations Pty Ltd (ZA arm)**

Gqeberha, Eastern Cape, South Africa

---

## Architecture

```
VV Entity Container
├── SafeKrypte        (primitive — HSM cryptographic root)
├── SafeStakes        (primitive — staked capital infrastructure)
├── First Principles  (method — deconstruct → reconstruct → integrate)
├── Underwriting      (function — comb → viability → profitability)
└── Ubuntu Pools      (application — stokvel digitalisation engine)
    └── SafeGrid      (application — edge-to-cloud security intel)
    └── SafeStakes    (platform — wagering harm reduction + B2B staking)
```

## Monorepo Structure

```
vv-monorepo/
├── packages/
│   ├── shared-kernel/        @vv/shared-kernel — typed events, types, utils
│   └── inference-router/     @vv/inference-router — Anthropic/Ollama router
├── apps/
│   ├── ubuntu-pools-api/     Fastify API — pools, members, contributions, credit
│   ├── ubuntu-pools-dashboard/ Next.js dashboard
│   ├── safegrid-api/         Fastify API — alerts, sites, stream ingestion
│   ├── safegrid-relay-go/    Go relay node — Redis pub/sub, stream processing
│   ├── safestakes-api/       Fastify API — stakes, velocity engine, redirect
│   ├── safekrypte/           HSM abstraction layer — keys, signing, quorum
│   ├── enterprise-gateway/   Per-tenant JWT gateway
│   └── lindiwe/              LINDIWE AI engine (DJ, Credit, SafeGrid, Velocity)
├── infra/
│   ├── docker/               Docker Compose + Dockerfiles
│   ├── scripts/              setup.sh, migrate.sh, gate1.sh, gate2.sh
│   └── terraform/            Vercel + Supabase IaC
├── tests/
│   ├── integration/          Per-service integration tests
│   ├── e2e/                  End-to-end flows
│   └── load/                 k6 load tests
└── .github/workflows/        CI + deploy pipelines
```

## Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| Node.js | ≥ 20 | All TypeScript apps |
| npm | ≥ 10 | Package management |
| Docker + Docker Compose | latest | Local infra |
| Go | ≥ 1.23 | SafeGrid relay node |
| Git | any | Version control |

## Quick Start

```bash
# 1. Clone
git clone https://github.com/vv-llc/vv-monorepo.git
cd vv-monorepo

# 2. Full setup (first time)
bash infra/scripts/setup.sh

# 3. Start all services
npm run dev

# 4. Verify health (GATE-2 north star)
npm run health
# → /api/health should return 200

# 5. Verify GATE-2 conditions
npm run gate2
```

## Current Milestone: GATE-2

**North star:** `GET /api/health` returns `200` from Vercel production URL.

```
GATE-1 ✅ — Production Supabase schema migrated. Pilot pool seeded. Real UUIDs confirmed.
GATE-2 🎯 — /api/health → 200 from vercel.app URL → Execute waitlist import (200 users)
```

## Agent Team (UBUNTU-PROTOCOL:CODEBASE/KND)

| Agent | Role | Mandate |
|-------|------|---------|
| ATLAS | SDLC Engine | Architecture, code review, ChatDev integration |
| NOVA | Infrastructure | Vercel, Supabase, Redis, Docker |
| KAYA | Operations | Daily health checks, friction log, reconciliation |
| LEX | Compliance | POPIA, NASASA, regulatory audit |
| LINDIWE | AI Intelligence | Ubuntu Score, SafeGrid Brain, Loss Velocity, Ubuntu DJ |

**Director:** Mihle Iviwe Majokweni (Mino) — approves all GATE events.

## Environment

Copy `.env.example` to `.env` and fill in values. See `.env.example` for all required variables.

**NEVER commit `.env` or any key material to git.**

## Tech Stack

- **API:** TypeScript + Fastify v5
- **ORM:** Drizzle ORM + postgres.js
- **Database:** PostgreSQL 16 + pgvector (Supabase)
- **Cache:** Redis 7
- **Queue:** Kafka (KRaft mode)
- **Relay:** Go 1.23
- **Frontend:** Next.js 15 (App Router)
- **AI:** Anthropic Claude (LINDIWE) | Ollama + Gemma4 (local inference)
- **Deploy:** Vercel (APIs + Dashboard)
- **CI/CD:** GitHub Actions

## Constitutional Principle

> *No entity may extract value from a vulnerable node.*
> — Ubuntu Meta-Protocol, VV Constitutional Amendment 2026

