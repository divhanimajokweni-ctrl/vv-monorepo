import type { Config } from 'jest'

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: '..',
  testMatch: ['**/tests/**/*.test.ts'],
  transform: { '^.+\\.tsx?$': ['ts-jest', { tsconfig: { esModuleInterop: true } }] },
  moduleNameMapper: {
    '^@vv/shared-kernel$': '<rootDir>/packages/shared-kernel/src/index.ts',
  },
  setupFilesAfterFramework: ['<rootDir>/tests/setup.ts'],
  verbose: true,
}
export default config
