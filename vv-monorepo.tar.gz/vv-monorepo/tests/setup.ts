// Global test setup
process.env.NODE_ENV = 'development'
process.env.HSM_MODE = 'software'
process.env.JWT_SECRET = 'test-secret-min-32-characters-long!!'
process.env.DATABASE_URL = process.env.DATABASE_URL ?? 'postgresql://postgres:postgres@localhost:5432/vv_test'
process.env.REDIS_URL = 'redis://localhost:6379'
process.env.SAFEKRYPTE_BASE_URL = 'http://localhost:3004'
process.env.SAFESTAKES_BASE_URL = 'http://localhost:3003'
