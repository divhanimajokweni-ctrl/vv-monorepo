import { buildServer } from '../../apps/ubuntu-pools-api/src/server'

describe('Ubuntu Pools API — Health', () => {
  let app: Awaited<ReturnType<typeof buildServer>>

  beforeAll(async () => {
    process.env.DATABASE_URL = process.env.DATABASE_URL ?? 'postgresql://postgres:postgres@localhost:5432/vv_test'
    process.env.JWT_SECRET = 'test-secret-min-32-characters-long!!'
    process.env.NODE_ENV = 'development'
    process.env.HSM_MODE = 'software'
    app = await buildServer()
  })

  afterAll(async () => {
    await app.close()
  })

  it('GET /api/health returns 200', async () => {
    const response = await app.inject({
      method: 'GET',
      url: '/api/health',
    })
    expect(response.statusCode).toBe(200)
    const body = JSON.parse(response.body)
    expect(body.status).toBe('ok')
    expect(body.gate).toBe('GATE-2-READY')
  })

  it('GET /api/health returns service name', async () => {
    const response = await app.inject({ method: 'GET', url: '/api/health' })
    const body = JSON.parse(response.body)
    expect(body.service).toBe('ubuntu-pools-api')
  })
})
