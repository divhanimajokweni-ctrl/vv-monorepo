import { LossVelocityEngine } from '../../apps/safestakes-api/src/engine/loss-velocity.engine'

describe('LossVelocityEngine', () => {
  const engine = new LossVelocityEngine()

  it('returns safe level for zero events', () => {
    const result = engine.calculateVelocity([])
    expect(result.level).toBe('safe')
    expect(result.triggerRedirect).toBe(false)
  })

  it('triggers redirect at critical velocity', () => {
    const events = Array.from({ length: 15 }, (_, i) => ({
      amount: 200,
      currency: 'ZAR',
      timestamp: new Date(Date.now() - i * 1000 * 60 * 10).toISOString(),
    }))
    const result = engine.calculateVelocity(events)
    expect(result.totalLoss).toBe(3000)
    expect(result.triggerRedirect).toBe(true)
  })

  it('calculates velocity score as a number between 0 and 100', () => {
    const events = [{ amount: 50, currency: 'ZAR', timestamp: new Date().toISOString() }]
    const result = engine.calculateVelocity(events)
    expect(result.velocityScore).toBeGreaterThanOrEqual(0)
    expect(result.velocityScore).toBeLessThanOrEqual(100)
  })
})
