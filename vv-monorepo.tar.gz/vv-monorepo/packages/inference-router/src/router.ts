export type InferenceMode = 'anthropic' | 'ollama' | 'hybrid'

export interface InferenceRequest {
  prompt: string
  systemPrompt?: string
  maxTokens?: number
  model?: string
  stream?: boolean
}

export interface InferenceResponse {
  content: string
  model: string
  provider: 'anthropic' | 'ollama'
  latencyMs: number
}

export class InferenceRouter {
  private mode: InferenceMode
  private anthropicKey?: string
  private ollamaBase: string

  constructor(opts: { mode?: InferenceMode; anthropicKey?: string; ollamaBase?: string }) {
    this.mode = opts.mode ?? 'anthropic'
    this.anthropicKey = opts.anthropicKey
    this.ollamaBase = opts.ollamaBase ?? 'http://localhost:11434'
  }

  async infer(req: InferenceRequest): Promise<InferenceResponse> {
    const start = Date.now()
    if (this.mode === 'anthropic') return this.anthropicInfer(req, start)
    if (this.mode === 'ollama') return this.ollamaInfer(req, start)
    // Hybrid: try ollama first, fall back to anthropic
    try { return await this.ollamaInfer(req, start) } catch {
      return this.anthropicInfer(req, start)
    }
  }

  private async anthropicInfer(req: InferenceRequest, start: number): Promise<InferenceResponse> {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.anthropicKey ?? '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: req.model ?? 'claude-sonnet-4-6',
        max_tokens: req.maxTokens ?? 1024,
        system: req.systemPrompt,
        messages: [{ role: 'user', content: req.prompt }],
      }),
    })
    const data = await res.json() as { content: Array<{ text: string }>; model: string }
    return { content: data.content[0].text, model: data.model, provider: 'anthropic', latencyMs: Date.now() - start }
  }

  private async ollamaInfer(req: InferenceRequest, start: number): Promise<InferenceResponse> {
    const res = await fetch(`${this.ollamaBase}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: req.model ?? 'gemma3:27b', prompt: req.prompt, stream: false }),
    })
    const data = await res.json() as { response: string; model: string }
    return { content: data.response, model: data.model, provider: 'ollama', latencyMs: Date.now() - start }
  }
}
