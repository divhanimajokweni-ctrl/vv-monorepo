import { z } from 'zod'

export const validateSAPhone = (phone: string): boolean => {
  // SA mobile: +27 6x/7x/8x xxxxxxx
  return /^\+27[678]\d{8}$/.test(phone)
}

export const validateSAID = (id: string): boolean => {
  if (id.length !== 13 || !/^\d+$/.test(id)) return false
  // Luhn check
  let sum = 0
  for (let i = 0; i < 13; i++) {
    let digit = parseInt(id[i])
    if (i % 2 === 1) { digit *= 2; if (digit > 9) digit -= 9 }
    sum += digit
  }
  return sum % 10 === 0
}

export const parseOrThrow = <T>(schema: z.ZodSchema<T>, data: unknown): T => {
  const result = schema.safeParse(data)
  if (!result.success) {
    throw new Error(`Validation failed: ${result.error.message}`)
  }
  return result.data
}
