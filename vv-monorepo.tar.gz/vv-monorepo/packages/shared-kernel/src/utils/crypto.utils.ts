import crypto from 'crypto'
import { v4 as uuidv4 } from 'uuid'

export const generateTraceId = (): string => uuidv4()

export const generateIdempotencyKey = (input: string): string => {
  return crypto.createHash('sha256').update(input).digest('hex')
}

export const hashPayload = (payload: Record<string, unknown>): string => {
  const normalized = JSON.stringify(payload, Object.keys(payload).sort())
  return crypto.createHash('sha256').update(normalized).digest('hex')
}

export const generateSalt = (bytes = 32): string => {
  return crypto.randomBytes(bytes).toString('hex')
}

export const maskSAID = (idNumber: string): string => {
  // POPIA: mask all but first 6 digits of South African ID
  return idNumber.substring(0, 6) + '******'
}

export const maskPhone = (phone: string): string => {
  return phone.substring(0, 4) + '****' + phone.substring(phone.length - 3)
}
