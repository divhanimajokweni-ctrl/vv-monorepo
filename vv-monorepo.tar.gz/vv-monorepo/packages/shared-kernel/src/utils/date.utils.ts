export const toISOString = (date: Date = new Date()): string => date.toISOString()

export const addDays = (date: Date, days: number): Date => {
  const result = new Date(date)
  result.setDate(result.getDate() + days)
  return result
}

export const isWithinWindow = (timestamp: string, windowHours: number): boolean => {
  const ts = new Date(timestamp).getTime()
  const now = Date.now()
  return now - ts <= windowHours * 60 * 60 * 1000
}

export const formatZADate = (date: Date): string => {
  return date.toLocaleDateString('en-ZA', { timeZone: 'Africa/Johannesburg' })
}
