import { z } from 'zod'

export const AlertEventSchema = z.object({
  type: z.literal('alert.detected'),
  alertId: z.string().uuid(),
  siteId: z.string().uuid(),
  cameraId: z.string(),
  severity: z.enum(['low', 'medium', 'high', 'critical']),
  threatType: z.string(),
  confidence: z.number().min(0).max(1),
  embedding: z.array(z.number()).optional(),
  isDuplicate: z.boolean(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export const SiteRegisteredEventSchema = z.object({
  type: z.literal('site.registered'),
  siteId: z.string().uuid(),
  tenantId: z.string().uuid(),
  name: z.string(),
  location: z.object({ lat: z.number(), lng: z.number(), suburb: z.string(), province: z.string() }),
  cameraCount: z.number().int(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export type AlertEvent = z.infer<typeof AlertEventSchema>
export type SiteRegisteredEvent = z.infer<typeof SiteRegisteredEventSchema>
export type SafeGridEvent = AlertEvent | SiteRegisteredEvent
