import { z } from 'zod'

export const PoolCreatedEventSchema = z.object({
  type: z.literal('pool.created'),
  poolId: z.string().uuid(),
  name: z.string(),
  adminId: z.string().uuid(),
  targetAmount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']),
  cycleType: z.enum(['monthly', 'weekly', 'biweekly']),
  maxMembers: z.number().int().positive(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export const PoolContributionEventSchema = z.object({
  type: z.literal('pool.contribution'),
  poolId: z.string().uuid(),
  memberId: z.string().uuid(),
  amount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']),
  transactionRef: z.string(),
  safekrypteSignature: z.string(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export const PoolPayoutEventSchema = z.object({
  type: z.literal('pool.payout'),
  poolId: z.string().uuid(),
  recipientId: z.string().uuid(),
  amount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']),
  quorumApprovalRef: z.string(),
  safekrypteSignature: z.string(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export type PoolCreatedEvent = z.infer<typeof PoolCreatedEventSchema>
export type PoolContributionEvent = z.infer<typeof PoolContributionEventSchema>
export type PoolPayoutEvent = z.infer<typeof PoolPayoutEventSchema>
export type PoolEvent = PoolCreatedEvent | PoolContributionEvent | PoolPayoutEvent
