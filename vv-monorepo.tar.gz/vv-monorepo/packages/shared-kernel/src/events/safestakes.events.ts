import { z } from 'zod'

export const StakeCreatedEventSchema = z.object({
  type: z.literal('stake.created'),
  stakeId: z.string().uuid(),
  stakerId: z.string().uuid(),
  poolId: z.string().uuid(),
  amount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']),
  upsideCondition: z.string(),
  downsideCondition: z.string(),
  safekrypteSignature: z.string(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export const LossVelocityTriggerEventSchema = z.object({
  type: z.literal('velocity.triggered'),
  userId: z.string().uuid(),
  velocityScore: z.number().min(0).max(100),
  windowHours: z.number(),
  totalLoss: z.number(),
  currency: z.enum(['ZAR', 'USD']),
  redirectPoolId: z.string().uuid().optional(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export const RedirectExecutedEventSchema = z.object({
  type: z.literal('redirect.executed'),
  userId: z.string().uuid(),
  sourceTransactionRef: z.string(),
  redirectAmount: z.number().positive(),
  destinationPoolId: z.string().uuid(),
  idempotencyKey: z.string(),
  safekrypteSignature: z.string(),
  timestamp: z.string().datetime(),
  traceId: z.string().uuid(),
})

export type StakeCreatedEvent = z.infer<typeof StakeCreatedEventSchema>
export type LossVelocityTriggerEvent = z.infer<typeof LossVelocityTriggerEventSchema>
export type RedirectExecutedEvent = z.infer<typeof RedirectExecutedEventSchema>
export type SafeStakesEvent = StakeCreatedEvent | LossVelocityTriggerEvent | RedirectExecutedEvent
