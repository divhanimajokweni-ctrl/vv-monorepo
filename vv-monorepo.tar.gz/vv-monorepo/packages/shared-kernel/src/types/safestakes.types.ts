import { z } from 'zod'

export const StakeStatusSchema = z.enum(['locked', 'released', 'slashed', 'pending'])
export const VelocityLevelSchema = z.enum(['safe', 'watch', 'warning', 'critical'])

export const StakeSchema = z.object({
  id: z.string().uuid(),
  stakePoolId: z.string().uuid(),
  stakerId: z.string().uuid(),
  amount: z.number().positive(),
  currency: z.enum(['ZAR', 'USD']),
  status: StakeStatusSchema,
  receiptHash: z.string(),
  upsideYield: z.number().min(0).optional(),
  slashPercentage: z.number().min(0).max(100).optional(),
  createdAt: z.string().datetime(),
  settledAt: z.string().datetime().nullable(),
})

export type StakeStatus = z.infer<typeof StakeStatusSchema>
export type VelocityLevel = z.infer<typeof VelocityLevelSchema>
export type Stake = z.infer<typeof StakeSchema>
