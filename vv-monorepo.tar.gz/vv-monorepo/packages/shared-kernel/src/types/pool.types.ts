import { z } from 'zod'

export const PoolStatusSchema = z.enum(['forming', 'active', 'completed', 'suspended', 'disputed'])
export const PoolTierSchema = z.enum(['community', 'professional', 'enterprise'])

export const PoolSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  status: PoolStatusSchema,
  tier: PoolTierSchema,
  adminId: z.string().uuid(),
  targetAmount: z.number().positive(),
  currentBalance: z.number().min(0),
  currency: z.enum(['ZAR', 'USD']),
  cycleType: z.enum(['monthly', 'weekly', 'biweekly']),
  maxMembers: z.number().int().positive(),
  memberCount: z.number().int().min(0),
  safekrypteKeyId: z.string(),
  safestakesPoolId: z.string().optional(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type PoolStatus = z.infer<typeof PoolStatusSchema>
export type PoolTier = z.infer<typeof PoolTierSchema>
export type Pool = z.infer<typeof PoolSchema>
