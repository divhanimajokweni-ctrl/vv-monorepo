import { z } from 'zod'

export const SeveritySchema = z.enum(['low', 'medium', 'high', 'critical'])
export const AlertStatusSchema = z.enum(['new', 'acknowledged', 'resolved', 'false_positive'])

export const AlertSchema = z.object({
  id: z.string().uuid(),
  siteId: z.string().uuid(),
  cameraId: z.string(),
  severity: SeveritySchema,
  threatType: z.string(),
  confidence: z.number().min(0).max(1),
  status: AlertStatusSchema,
  isDuplicate: z.boolean(),
  deduplicationHash: z.string().optional(),
  embedding: z.array(z.number()).optional(),
  timestamp: z.string().datetime(),
  resolvedAt: z.string().datetime().nullable(),
})

export type Severity = z.infer<typeof SeveritySchema>
export type AlertStatus = z.infer<typeof AlertStatusSchema>
export type Alert = z.infer<typeof AlertSchema>
