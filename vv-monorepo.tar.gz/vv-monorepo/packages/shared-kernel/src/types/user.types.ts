import { z } from 'zod'

export const UserRoleSchema = z.enum(['member', 'admin', 'operator', 'director', 'auditor'])
export const UserStatusSchema = z.enum(['active', 'suspended', 'pending_verification', 'offboarded'])

export const UserSchema = z.object({
  id: z.string().uuid(),
  phone: z.string(),
  idNumber: z.string().optional(),  // SAID — POPIA protected
  firstName: z.string(),
  lastName: z.string(),
  role: UserRoleSchema,
  status: UserStatusSchema,
  ubuntuScore: z.number().min(0).max(1000).optional(),
  popiaConsentAt: z.string().datetime().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type UserRole = z.infer<typeof UserRoleSchema>
export type UserStatus = z.infer<typeof UserStatusSchema>
export type User = z.infer<typeof UserSchema>
