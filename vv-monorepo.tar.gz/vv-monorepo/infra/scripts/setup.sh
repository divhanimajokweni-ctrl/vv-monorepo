#!/usr/bin/env bash
# VV Monorepo — Full local development setup
# Run once after cloning: bash infra/scripts/setup.sh

set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

log() { echo -e "${GREEN}[VV-SETUP]${NC} $1"; }
warn() { echo -e "${YELLOW}[VV-WARN]${NC} $1"; }
err() { echo -e "${RED}[VV-ERROR]${NC} $1"; exit 1; }

log "Starting VV Monorepo setup..."

# Prerequisites check
command -v node >/dev/null 2>&1 || err "Node.js ≥ 20 required. Install from https://nodejs.org"
command -v npm >/dev/null 2>&1 || err "npm required"
command -v docker >/dev/null 2>&1 || err "Docker required. Install from https://docker.com"
command -v go >/dev/null 2>&1 || warn "Go not found — SafeGrid relay won't build locally"

NODE_VER=$(node --version | cut -d'.' -f1 | tr -d 'v')
[ "$NODE_VER" -ge 20 ] || err "Node.js ≥ 20 required, found $(node --version)"

# Copy env file
if [ ! -f .env ]; then
  cp .env.example .env
  log "Created .env from .env.example — fill in real values before production"
else
  warn ".env already exists — skipping copy"
fi

# Install dependencies
log "Installing npm dependencies..."
npm install --legacy-peer-deps

# Build shared packages first
log "Building shared-kernel..."
npm run build -- --filter=@vv/shared-kernel

# Start infrastructure
log "Starting Docker infrastructure (postgres, redis, kafka)..."
docker compose -f infra/docker/docker-compose.yml up -d postgres redis

# Wait for postgres
log "Waiting for postgres to be ready..."
for i in $(seq 1 30); do
  docker exec vv-postgres pg_isready -U postgres >/dev/null 2>&1 && break
  echo -n "."
  sleep 1
done
echo ""

# Enable pgvector extension
log "Enabling pgvector extension..."
docker exec vv-postgres psql -U postgres -c "CREATE EXTENSION IF NOT EXISTS vector;" >/dev/null 2>&1 || true

# Run migrations
log "Running database migrations..."
npm run migrate

# Seed pilot data
log "Seeding pilot data..."
npm run db:seed

log ""
log "╔════════════════════════════════════════════╗"
log "║  VV Monorepo setup complete                ║"
log "║                                            ║"
log "║  Start all services: npm run dev           ║"
log "║  Health check:       npm run health        ║"
log "║  Gate 2 verify:      npm run gate2         ║"
log "╚════════════════════════════════════════════╝"
