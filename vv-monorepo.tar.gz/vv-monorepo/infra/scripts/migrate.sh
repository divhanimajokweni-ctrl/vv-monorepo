#!/usr/bin/env bash
# Run Drizzle migrations for all apps

set -euo pipefail
log() { echo "[VV-MIGRATE] $1"; }

log "Running migrations for ubuntu-pools-api..."
cd apps/ubuntu-pools-api && npx drizzle-kit push && cd ../..

log "Running migrations for safegrid-api..."
cd apps/safegrid-api && npx drizzle-kit push && cd ../..

log "Running migrations for safestakes-api..."
cd apps/safestakes-api && npx drizzle-kit push && cd ../..

log "✅ All migrations complete"
