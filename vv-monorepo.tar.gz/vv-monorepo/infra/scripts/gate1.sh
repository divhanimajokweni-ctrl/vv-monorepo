#!/usr/bin/env bash
# GATE-1 verification: Production Supabase schema migration + pilot pool seeding
# GATE-1 was completed with real Postgres UUIDs confirmed.
# This script verifies GATE-1 conditions are still met.

set -euo pipefail
GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

echo "🔍 Verifying GATE-1 conditions..."

# Check 1: pools table exists
POOLS_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM pools;" 2>/dev/null | tr -d ' ')
if [ -z "$POOLS_COUNT" ] || [ "$POOLS_COUNT" -eq 0 ]; then
  echo -e "${RED}❌ GATE-1 FAIL: No pools found in database${NC}"
  exit 1
fi
echo -e "${GREEN}✅ Pools table: $POOLS_COUNT record(s)${NC}"

# Check 2: users table has pilot members
USERS_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM users;" 2>/dev/null | tr -d ' ')
echo -e "${GREEN}✅ Users table: $USERS_COUNT record(s)${NC}"

# Check 3: pgvector extension enabled
VECTOR=$(psql "$DATABASE_URL" -t -c "SELECT 1 FROM pg_extension WHERE extname='vector';" 2>/dev/null | tr -d ' ')
if [ "$VECTOR" != "1" ]; then
  echo -e "${RED}❌ GATE-1 FAIL: pgvector extension not enabled${NC}"
  exit 1
fi
echo -e "${GREEN}✅ pgvector extension: enabled${NC}"

echo ""
echo -e "${GREEN}✅ GATE-1 VERIFIED. Proceed to GATE-2.${NC}"
