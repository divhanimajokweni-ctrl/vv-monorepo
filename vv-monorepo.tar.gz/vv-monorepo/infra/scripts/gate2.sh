#!/usr/bin/env bash
# GATE-2 verification: /api/health → 200 from production Vercel URL
# Then execute waitlist import (200 users)

set -euo pipefail
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'

HEALTH_URL="${HEALTH_URL:-https://ubuntu-pools-api.vercel.app/api/health}"
ADMIN_TOKEN="${ADMIN_TOKEN:-}"

echo "╔══════════════════════════════════════════╗"
echo "║         GATE-2 VERIFICATION              ║"
echo "║  North star: /api/health → 200           ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Step 1: health check
echo "Step 1: Health check..."
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL")
if [ "$STATUS" != "200" ]; then
  echo -e "${RED}❌ GATE-2 FAIL: /api/health returned $STATUS${NC}"
  exit 1
fi
echo -e "${GREEN}✅ /api/health → 200${NC}"

# Step 2: verify gate field in response
GATE=$(curl -s "$HEALTH_URL" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('gate',''))" 2>/dev/null || echo "")
if [[ "$GATE" == *"GATE"* ]]; then
  echo -e "${GREEN}✅ Gate indicator: $GATE${NC}"
fi

echo ""
echo -e "${GREEN}✅ GATE-2 CONDITIONS MET.${NC}"
echo -e "${YELLOW}Next step: Execute waitlist import (200 users)${NC}"
echo "  Run: npm run db:seed -- --waitlist-import"
