#!/usr/bin/env bash
# Health check — verifies /api/health returns 200
# This is the GATE-2 north star condition

set -euo pipefail
GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

HEALTH_URL="${HEALTH_URL:-http://localhost:3001/api/health}"
MAX_ATTEMPTS=12
INTERVAL=5

echo "🔍 Checking: $HEALTH_URL"
for i in $(seq 1 $MAX_ATTEMPTS); do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
  if [ "$STATUS" = "200" ]; then
    echo -e "${GREEN}✅ /api/health → 200. Service is healthy.${NC}"
    BODY=$(curl -s "$HEALTH_URL")
    echo "Response: $BODY"
    exit 0
  fi
  echo "  Attempt $i/$MAX_ATTEMPTS: status=$STATUS — retrying in ${INTERVAL}s..."
  sleep $INTERVAL
done

echo -e "${RED}❌ Health check failed after $MAX_ATTEMPTS attempts.${NC}"
exit 1
